<template>
  <div class="top-bar">
    <div class="top-bar-left">
      <h1 class="app-title">Minecraft Map Viewer</h1>
    </div>
    
    <div class="top-bar-center">
      <div class="coord-display">
        <span class="coord-label">X:</span>
        <span class="coord-value">{{ Math.round(mouseWorldCoord.x) }}</span>
        <span class="coord-label">Z:</span>
        <span class="coord-value">{{ Math.round(mouseWorldCoord.z) }}</span>
      </div>
    </div>
    
    <div class="top-bar-right">
      <div class="zoom-display">
        <span class="zoom-label">缩放:</span>
        <span class="zoom-value">{{ zoomPercent }}%</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { mouseWorldCoord, zoomPercent } from '@/stores/mapStore'
</script>

<style scoped>
.top-bar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 52px;
  background: color-mix(in oklab, var(--morandi-cream) 84%, #000000 16%);
  border-bottom: 1px solid var(--ui-border);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  z-index: 100;
  box-shadow: var(--ui-shadow);
}

.top-bar-left,
.top-bar-center,
.top-bar-right {
  display: flex;
  align-items: center;
  gap: 12px;
}

.app-title {
  font-size: 16px;
  font-weight: 600;
  color: var(--ui-ink);
  margin: 0;
}

.coord-display {
  display: flex;
  align-items: center;
  gap: 8px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 13px;
  background: color-mix(in oklab, var(--morandi-stone) 74%, #000000 26%);
  padding: 6px 12px;
  border-radius: 6px;
  border: 1px solid var(--ui-border);
}

.coord-label {
  color: var(--ui-muted);
}

.coord-value {
  color: var(--morandi-slate);
  font-weight: 500;
  min-width: 60px;
  text-align: right;
}

.zoom-display {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  background: color-mix(in oklab, var(--morandi-stone) 74%, #000000 26%);
  padding: 6px 12px;
  border-radius: 6px;
  border: 1px solid var(--ui-border);
}

.zoom-label {
  color: var(--ui-muted);
}

.zoom-value {
  color: #6b7f71;
  font-weight: 500;
  min-width: 40px;
  text-align: right;
}

@media (max-width: 768px) {
  .top-bar {
    padding: 0 12px;
  }
  
  .app-title {
    font-size: 13px;
  }
  
  .coord-display {
    font-size: 11px;
    padding: 4px 8px;
  }
  
  .coord-value {
    min-width: 45px;
  }
  
  .zoom-display {
    display: none;
  }

  .top-bar-center {
    margin-left: auto;
  }
}
</style>
