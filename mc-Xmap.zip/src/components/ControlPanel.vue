<template>
  <button
    v-if="isCollapsed"
    class="panel-toggle-btn open-btn"
    @click="isCollapsed = false"
    title="打开控制面板"
  >
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M4 6h16M4 12h16M4 18h16" />
    </svg>
    <span>菜单</span>
  </button>

  <Transition name="panel-slide">
    <div v-show="!isCollapsed" class="control-panel">
      <button class="panel-toggle-btn close-btn" @click="isCollapsed = true" title="关闭控制面板">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>

      <div class="panel-header">
        <h2 class="panel-title">导航面板</h2>
        <p class="panel-subtitle">标记请在 <code>public/markers.json</code> 维护</p>
      </div>

      <div class="panel-content">
        <section class="section">
          <h3 class="section-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10" />
              <path d="M12 8v8M8 12h8" />
            </svg>
            坐标跳转
          </h3>
          <div class="coord-inputs">
            <div class="input-group">
              <label>X</label>
              <input v-model.number="jumpX" type="number" placeholder="X 坐标" @keyup.enter="handleJump" />
            </div>
            <div class="input-group">
              <label>Z</label>
              <input v-model.number="jumpZ" type="number" placeholder="Z 坐标" @keyup.enter="handleJump" />
            </div>
          </div>
          <button class="btn btn-primary" @click="handleJump">跳转</button>
        </section>

        <section class="section">
          <h3 class="section-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35" />
            </svg>
            缩放控制
          </h3>
          <div class="zoom-controls">
            <button class="btn btn-secondary zoom-btn" @click="handleZoomOut">-</button>
            <span class="zoom-value">{{ zoomPercent }}%</span>
            <button class="btn btn-secondary zoom-btn" @click="handleZoomIn">+</button>
          </div>
          <button class="btn btn-secondary btn-full" @click="handleReset">重置视图</button>
        </section>

        <section class="section">
          <h3 class="section-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
              <circle cx="12" cy="10" r="3" />
            </svg>
            标记列表
            <span class="marker-count">({{ filteredMarkers.length }})</span>
          </h3>
          <div class="search-box">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35" />
            </svg>
            <input v-model="searchQuery" type="text" placeholder="搜索标记..." />
          </div>
          <div class="marker-list">
            <button
              v-for="marker in filteredMarkers"
              :key="marker.id"
              class="marker-item"
              @click="jumpToMarker(marker)"
              title="跳转到标记"
            >
              <span class="marker-color" :style="{ backgroundColor: marker.color }"></span>
              <span class="marker-name">{{ marker.name }}</span>
              <span class="marker-coord">X {{ marker.x }} / Z {{ marker.z }}</span>
            </button>
            <div v-if="filteredMarkers.length === 0" class="empty-state">没有找到标记</div>
          </div>
        </section>
      </div>
    </div>
  </Transition>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { camera, jumpToCoord, markers, searchMarkers, setZoom, zoomPercent } from '@/stores/mapStore'
import type { Marker } from '@/types'

const isCollapsed = ref(window.innerWidth <= 768)

const jumpX = ref(0)
const jumpZ = ref(0)
const searchQuery = ref('')

function handleJump() {
  jumpToCoord(jumpX.value, jumpZ.value)
}

function handleZoomIn() {
  setZoom(camera.zoom * 1.25, window.innerWidth / 2, window.innerHeight / 2)
}

function handleZoomOut() {
  setZoom(camera.zoom * 0.75, window.innerWidth / 2, window.innerHeight / 2)
}

function handleReset() {
  jumpToCoord(0, 0, 1)
}

const filteredMarkers = computed(() => {
  if (!searchQuery.value.trim()) return markers.value
  return searchMarkers(searchQuery.value)
})

function jumpToMarker(marker: Marker) {
  jumpToCoord(marker.x, marker.z)
}

const onResize = () => {
  if (window.innerWidth <= 768 && !isCollapsed.value) return
  if (window.innerWidth > 768 && isCollapsed.value) {
    isCollapsed.value = false
  }
}

onMounted(() => {
  window.addEventListener('resize', onResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', onResize)
})
</script>

<style scoped>
.panel-slide-enter-active,
.panel-slide-leave-active {
  transition: transform 0.24s ease, opacity 0.24s ease;
}

.panel-slide-enter-from,
.panel-slide-leave-to {
  transform: translateX(-100%);
  opacity: 0;
}

.open-btn {
  position: fixed;
  left: 16px;
  bottom: 20px;
  z-index: 100;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  border-radius: 12px;
  border: 1px solid var(--ui-border);
  background: color-mix(in oklab, var(--morandi-sage) 56%, #000000 44%);
  color: var(--ui-ink);
  box-shadow: var(--ui-shadow);
  cursor: pointer;
}

.open-btn svg {
  width: 18px;
  height: 18px;
}

.control-panel {
  position: fixed;
  top: 52px;
  bottom: 0;
  left: 0;
  width: 340px;
  background: color-mix(in oklab, var(--morandi-cream) 88%, #000000 12%);
  border-right: 1px solid var(--ui-border);
  z-index: 96;
  display: flex;
  flex-direction: column;
  box-shadow: var(--ui-shadow);
}

.close-btn {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: 1px solid var(--ui-border);
  background: color-mix(in oklab, var(--morandi-stone) 76%, #000000 24%);
  color: var(--ui-ink);
  cursor: pointer;
}

.panel-header {
  padding: 16px 20px 14px;
  border-bottom: 1px solid var(--ui-border);
}

.panel-title {
  margin: 0 0 6px;
  font-size: 17px;
  letter-spacing: 0.3px;
  color: var(--ui-ink);
}

.panel-subtitle {
  margin: 0;
  font-size: 12px;
  color: var(--ui-muted);
}

.panel-subtitle code {
  color: #cfc7be;
}

.panel-content {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}

.section {
  margin-bottom: 14px;
  padding: 14px;
  border: 1px solid var(--ui-border);
  border-radius: 14px;
  background: color-mix(in oklab, var(--morandi-cream) 92%, #000000 8%);
}

.section:last-child {
  margin-bottom: 0;
}

.section-title {
  margin: 0 0 12px;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: var(--ui-muted);
}

.section-title svg {
  width: 16px;
  height: 16px;
  stroke: var(--morandi-slate);
}

.marker-count {
  margin-left: auto;
}

.coord-inputs {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-bottom: 10px;
}

.input-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.input-group label {
  font-size: 12px;
  color: var(--ui-muted);
}

.input-group input,
.search-box input {
  width: 100%;
  padding: 10px 11px;
  border-radius: 9px;
  border: 1px solid var(--ui-border);
  background: rgba(9, 11, 10, 0.72);
  color: var(--ui-ink);
  outline: none;
}

.input-group input:focus,
.search-box input:focus {
  border-color: var(--morandi-slate);
  box-shadow: 0 0 0 2px color-mix(in oklab, var(--morandi-slate) 36%, #000000 64%);
}

.btn {
  border: 1px solid var(--ui-border);
  border-radius: 10px;
  padding: 10px 12px;
  font-size: 14px;
  cursor: pointer;
  display: inline-flex;
  justify-content: center;
  align-items: center;
}

.btn-primary {
  width: 100%;
  background: linear-gradient(
    130deg,
    color-mix(in oklab, var(--morandi-sage) 66%, #000000 34%),
    color-mix(in oklab, var(--morandi-taupe) 66%, #000000 34%)
  );
  color: #f2ede7;
}

.btn-secondary {
  background: color-mix(in oklab, var(--morandi-stone) 74%, #000000 26%);
  color: var(--ui-ink);
}

.btn-full {
  width: 100%;
  margin-top: 10px;
}

.zoom-controls {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.zoom-btn {
  width: 40px;
  height: 40px;
  font-size: 20px;
  padding: 0;
}

.zoom-value {
  min-width: 72px;
  text-align: center;
  color: #8fa0aa;
  font-weight: 700;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
}

.search-box {
  position: relative;
  margin-bottom: 10px;
}

.search-box svg {
  position: absolute;
  left: 10px;
  top: 50%;
  transform: translateY(-50%);
  width: 16px;
  height: 16px;
  stroke: var(--ui-muted);
  pointer-events: none;
}

.search-box input {
  padding-left: 32px;
}

.marker-list {
  max-height: 240px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.marker-item {
  display: grid;
  grid-template-columns: 12px 1fr auto;
  align-items: center;
  gap: 10px;
  padding: 9px 10px;
  border: 1px solid var(--ui-border);
  border-radius: 10px;
  background: rgba(9, 11, 10, 0.72);
  color: var(--ui-ink);
  cursor: pointer;
  text-align: left;
}

.marker-item:hover {
  border-color: color-mix(in oklab, var(--morandi-slate) 75%, #000000 25%);
  background: rgba(12, 15, 13, 0.86);
}

.marker-color {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}

.marker-name {
  font-size: 13px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.marker-coord {
  font-size: 11px;
  color: var(--ui-muted);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
}

.empty-state {
  text-align: center;
  color: var(--ui-muted);
  font-size: 12px;
  padding: 14px;
}

@media (max-width: 900px) {
  .control-panel {
    width: min(88vw, 360px);
  }
}

@media (max-width: 768px) {
  .control-panel {
    top: 52px;
    width: 100%;
  }

  .open-btn {
    left: 12px;
    bottom: 72px;
  }

  .open-btn span {
    display: none;
  }
}
</style>
