<template>
  <div class="app">
    <TopBar />
    <ControlPanel />
    <div class="map-container">
      <MapCanvas />
    </div>
    <FloatingControls />
  </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import TopBar from '@/components/TopBar.vue'
import ControlPanel from '@/components/ControlPanel.vue'
import MapCanvas from '@/components/MapCanvas.vue'
import FloatingControls from '@/components/FloatingControls.vue'
import { loadTileIndex, loadMarkers } from '@/stores/mapStore'

onMounted(async () => {
  // 加载瓦片索引
  await loadTileIndex()
  
  // 加载标记
  await loadMarkers()
})
</script>

<style scoped>
.app {
  width: 100%;
  height: 100%;
  position: relative;
  overflow: hidden;
}

.map-container {
  position: fixed;
  top: 52px;
  left: 0;
  right: 0;
  bottom: 0;
  background: #000000;
}

@media (max-width: 768px) {
  .map-container {
    top: 52px;
  }
}
</style>
