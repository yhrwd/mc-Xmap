import { ref, onMounted, onUnmounted, type Ref } from 'vue'
import type { TileInfo, Marker } from '@/types'
import {
  camera,
  canvasSize,
  getVisibleTiles,
  worldToScreen,
  TILE_SIZE,
  hoveredMarkerId,
} from '@/stores/mapStore'
import { loadTileImage, getCachedTile, preloadTiles } from '@/utils/tileCache'

type RenderTile = TileInfo & { worldSize?: number; level?: number }

interface MipLevelManifest {
  level: number
  worldSize: number
  tiles: Array<Pick<TileInfo, 'x' | 'z' | 'filename' | 'path'>>
}

interface MipManifest {
  tileSize: number
  xOffset: number
  levels: MipLevelManifest[]
}

interface MipLevelData {
  level: number
  worldSize: number
  lookup: Map<string, RenderTile>
}

const X_OFFSET = 512

function getTileKey(x: number, z: number): string {
  return `${x}_${z}`
}

export function useMapRenderer(canvasRef: Ref<HTMLCanvasElement | null>) {
  const ctx = ref<CanvasRenderingContext2D | null>(null)
  const offscreenCanvas = ref<HTMLCanvasElement | null>(null)
  const offscreenCtx = ref<CanvasRenderingContext2D | null>(null)
  const animationFrameId = ref<number | null>(null)
  const pendingRender = ref(false)
  const mipLevels = ref<MipLevelData[]>([])
  let loadJobId = 0

  async function loadMipManifest() {
    try {
      const response = await fetch('/tiles/mip/manifest.json')
      if (!response.ok) return

      const manifest = (await response.json()) as MipManifest
      if (!manifest.levels || manifest.levels.length === 0) return

      mipLevels.value = manifest.levels
        .map((level) => {
          const lookup = new Map<string, RenderTile>()
          for (const tile of level.tiles) {
            const renderTile: RenderTile = {
              col: 0,
              row: 0,
              x: tile.x,
              z: tile.z,
              filename: tile.filename,
              path: tile.path,
              worldSize: level.worldSize,
              level: level.level,
            }
            lookup.set(getTileKey(tile.x, tile.z), renderTile)
          }
          return {
            level: level.level,
            worldSize: level.worldSize,
            lookup,
          }
        })
        .sort((a, b) => a.level - b.level)
    } catch {
      mipLevels.value = []
    }
  }

  // 初始化 Canvas
  function initCanvas() {
    if (!canvasRef.value) return

    const canvas = canvasRef.value
    ctx.value = canvas.getContext('2d', { alpha: false })

    if (!ctx.value) {
      console.error('Failed to get canvas context')
      return
    }
    // 创建离屏 canvas 用于双缓冲
    offscreenCanvas.value = document.createElement('canvas')
    offscreenCtx.value = offscreenCanvas.value.getContext('2d', { alpha: false })

    if (!offscreenCtx.value) {
      console.error('Failed to create offscreen context')
      return
    }

    ctx.value.imageSmoothingEnabled = false
    offscreenCtx.value.imageSmoothingEnabled = false
    resizeCanvas()
  }

  // 调整画布尺寸
  function resizeCanvas() {
    if (!canvasRef.value || !ctx.value || !offscreenCanvas.value || !offscreenCtx.value) return

    const canvas = canvasRef.value
    const dpr = window.devicePixelRatio || 1

    const parent = canvas.parentElement
    if (parent) {
      canvasSize.value.width = parent.clientWidth
      canvasSize.value.height = parent.clientHeight
    }

    const width = canvasSize.value.width
    const height = canvasSize.value.height

    canvas.width = width * dpr
    canvas.height = height * dpr
    offscreenCanvas.value.width = width * dpr
    offscreenCanvas.value.height = height * dpr

    canvas.style.width = `${width}px`
    canvas.style.height = `${height}px`

    ctx.value.setTransform(1, 0, 0, 1, 0, 0)
    offscreenCtx.value.setTransform(1, 0, 0, 1, 0, 0)
    ctx.value.scale(dpr, dpr)
    offscreenCtx.value.scale(dpr, dpr)
    ctx.value.imageSmoothingEnabled = false
    offscreenCtx.value.imageSmoothingEnabled = false
  }

  function renderTileToOffscreen(tile: RenderTile) {
    if (!offscreenCtx.value) return

    const image = getCachedTile(tile)
    if (!image) return

    const screenPos = worldToScreen(tile.x, tile.z)
    const worldSize = tile.worldSize ?? TILE_SIZE
    const scaledSize = worldSize * camera.zoom
    offscreenCtx.value.drawImage(image, screenPos.x, screenPos.y, scaledSize, scaledSize)
  }

  function renderBlackBackgroundToOffscreen() {
    if (!offscreenCtx.value) return

    offscreenCtx.value.fillStyle = '#000000'
    offscreenCtx.value.fillRect(0, 0, canvasSize.value.width, canvasSize.value.height)
  }

  function renderGridToOffscreen() {
    if (!offscreenCtx.value || camera.zoom < 0.5) return

    offscreenCtx.value.strokeStyle = 'rgba(255, 255, 255, 0.1)'
    offscreenCtx.value.lineWidth = 1

    const bounds = {
      minX:
        Math.floor((camera.x - canvasSize.value.width / 2 / camera.zoom) / TILE_SIZE) * TILE_SIZE,
      maxX:
        Math.ceil((camera.x + canvasSize.value.width / 2 / camera.zoom) / TILE_SIZE) * TILE_SIZE,
      minZ:
        Math.floor((camera.z - canvasSize.value.height / 2 / camera.zoom) / TILE_SIZE) * TILE_SIZE,
      maxZ:
        Math.ceil((camera.z + canvasSize.value.height / 2 / camera.zoom) / TILE_SIZE) * TILE_SIZE,
    }

    offscreenCtx.value.beginPath()

    for (let x = bounds.minX; x <= bounds.maxX; x += TILE_SIZE) {
      const screenX = worldToScreen(x, 0).x
      offscreenCtx.value.moveTo(screenX, 0)
      offscreenCtx.value.lineTo(screenX, canvasSize.value.height)
    }

    for (let z = bounds.minZ; z <= bounds.maxZ; z += TILE_SIZE) {
      const screenY = worldToScreen(0, z).y
      offscreenCtx.value.moveTo(0, screenY)
      offscreenCtx.value.lineTo(canvasSize.value.width, screenY)
    }

    offscreenCtx.value.stroke()
  }

  function renderMarkersToOffscreen(markers: Marker[]) {
    if (!offscreenCtx.value) return

    for (const marker of markers) {
      const screenPos = worldToScreen(marker.x, marker.z)
      const isHovered = hoveredMarkerId.value === marker.id

      if (
        screenPos.x < -30 ||
        screenPos.x > canvasSize.value.width + 30 ||
        screenPos.y < -30 ||
        screenPos.y > canvasSize.value.height + 30
      ) {
        continue
      }

      // 标记点半径限制上限，避免高倍缩放时遮挡过大
      const radius = (Math.min(8, Math.max(4, 1 * camera.zoom)) + (isHovered ? 1 : 0))

      offscreenCtx.value.beginPath()
      offscreenCtx.value.arc(screenPos.x, screenPos.y, radius + 2, 0, Math.PI * 2)
      offscreenCtx.value.fillStyle = isHovered ? '#fef3c7' : '#ffffff'
      offscreenCtx.value.fill()

      offscreenCtx.value.beginPath()
      offscreenCtx.value.arc(screenPos.x, screenPos.y, radius, 0, Math.PI * 2)
      offscreenCtx.value.fillStyle = marker.color
      offscreenCtx.value.fill()

      if (camera.zoom > 0.8 || isHovered) {
        if (isHovered) {
          const text = marker.name
          offscreenCtx.value.font = '12px Inter, sans-serif'
          const textWidth = offscreenCtx.value.measureText(text).width
          const boxWidth = textWidth + 16
          const boxHeight = 22
          const boxX = screenPos.x - boxWidth / 2
          const boxY = screenPos.y - radius - boxHeight - 8

          offscreenCtx.value.fillStyle = 'rgba(20, 20, 20, 0.85)'
          offscreenCtx.value.fillRect(boxX, boxY, boxWidth, boxHeight)
        }

        offscreenCtx.value.font = '12px Inter, sans-serif'
        offscreenCtx.value.fillStyle = '#ffffff'
        offscreenCtx.value.textAlign = 'center'
        offscreenCtx.value.textBaseline = isHovered ? 'middle' : 'top'
        offscreenCtx.value.fillText(
          marker.name,
          screenPos.x,
          isHovered ? screenPos.y - radius - 19 : screenPos.y + radius + 6,
        )
      }
    }
  }

  function copyToDisplay() {
    if (!ctx.value || !offscreenCanvas.value) return

    const dpr = window.devicePixelRatio || 1
    ctx.value.setTransform(1, 0, 0, 1, 0, 0)

    ctx.value.drawImage(
      offscreenCanvas.value,
      0,
      0,
      canvasSize.value.width * dpr,
      canvasSize.value.height * dpr,
      0,
      0,
      canvasSize.value.width * dpr,
      canvasSize.value.height * dpr,
    )

    ctx.value.scale(dpr, dpr)
  }

  function selectMipLevel(): MipLevelData | null {
    if (mipLevels.value.length === 0) return null
    const targetScreenSize = 140
    const firstLevel = mipLevels.value[0]
    if (!firstLevel) return null
    let best: MipLevelData = firstLevel
    let bestScore = Infinity

    for (const level of mipLevels.value) {
      const screenSize = level.worldSize * camera.zoom
      let score = Math.abs(screenSize - targetScreenSize)
      if (screenSize < 28) score += (28 - screenSize) * 4
      if (score < bestScore) {
        best = level
        bestScore = score
      }
    }
    return best
  }

  function getVisibleTilesForLevel(level: MipLevelData): RenderTile[] {
    const halfWidth = canvasSize.value.width / 2 / camera.zoom
    const halfHeight = canvasSize.value.height / 2 / camera.zoom
    const bounds = {
      minX: camera.x - halfWidth,
      maxX: camera.x + halfWidth,
      minZ: camera.z - halfHeight,
      maxZ: camera.z + halfHeight,
    }

    const step = level.worldSize
    const startX = Math.floor((bounds.minX - X_OFFSET) / step) * step + X_OFFSET
    const endX = Math.floor((bounds.maxX - X_OFFSET) / step) * step + X_OFFSET
    const startZ = Math.floor(bounds.minZ / step) * step
    const endZ = Math.floor(bounds.maxZ / step) * step

    const visible: RenderTile[] = []
    for (let x = startX; x <= endX; x += step) {
      for (let z = startZ; z <= endZ; z += step) {
        const tile = level.lookup.get(getTileKey(x, z))
        if (tile) visible.push(tile)
      }
    }
    return visible
  }

  function getActiveVisibleTiles(): RenderTile[] {
    const selectedLevel = selectMipLevel()
    if (!selectedLevel || selectedLevel.level === 0) {
      return getVisibleTiles()
    }
    return getVisibleTilesForLevel(selectedLevel)
  }

  function renderSync(markers: Marker[] = []) {
    if (!offscreenCtx.value) return

    renderBlackBackgroundToOffscreen()
    const visibleTiles = getActiveVisibleTiles()

    for (const tile of visibleTiles) {
      if (getCachedTile(tile)) {
        renderTileToOffscreen(tile)
      }
    }

    renderGridToOffscreen()
    renderMarkersToOffscreen(markers)
    copyToDisplay()
  }

  async function loadMissingTiles(markers: Marker[] = []) {
    const jobId = ++loadJobId
    const visibleTiles = getActiveVisibleTiles()
    const missingTiles = visibleTiles.filter((tile) => !getCachedTile(tile))
    if (missingTiles.length === 0) {
      void preloadSurroundingTiles()
      return
    }

    missingTiles.sort((a, b) => {
      const da = (a.x - camera.x) ** 2 + (a.z - camera.z) ** 2
      const db = (b.x - camera.x) ** 2 + (b.z - camera.z) ** 2
      return da - db
    })

    const selectedLevel = selectMipLevel()
    const levelSize = selectedLevel?.worldSize ?? TILE_SIZE
    const concurrency =
      levelSize >= TILE_SIZE * 8 ? 10 : camera.zoom <= 0.2 ? 16 : camera.zoom <= 0.5 ? 10 : 6

    let cursor = 0
    let loadedCount = 0

    const workers = Array.from({ length: concurrency }, async () => {
      while (cursor < missingTiles.length) {
        const currentIndex = cursor++
        const tile = missingTiles[currentIndex]
        if (!tile || jobId !== loadJobId) return

        await loadTileImage(tile, 'high')
        loadedCount++

        if (loadedCount % 12 === 0 && jobId === loadJobId) {
          requestRender(markers)
        }
      }
    })

    await Promise.all(workers)
    if (jobId !== loadJobId) return

    requestRender(markers)
    void preloadSurroundingTiles()
  }

  function requestRender(markers: Marker[] = []) {
    if (pendingRender.value) return

    pendingRender.value = true
    animationFrameId.value = requestAnimationFrame(() => {
      pendingRender.value = false
      renderSync(markers)
    })
  }

  async function preloadSurroundingTiles() {
    const selectedLevel = selectMipLevel()
    const visibleTiles =
      selectedLevel && selectedLevel.level > 0 ? getVisibleTilesForLevel(selectedLevel) : getVisibleTiles()
    if (visibleTiles.length === 0) return

    const worldSize = selectedLevel?.worldSize ?? TILE_SIZE
    const ring = camera.zoom <= 0.2 ? 2 : 1
    const bounds = {
      minX: Math.min(...visibleTiles.map((t) => t.x)) - worldSize * ring,
      maxX: Math.max(...visibleTiles.map((t) => t.x)) + worldSize * ring,
      minZ: Math.min(...visibleTiles.map((t) => t.z)) - worldSize * ring,
      maxZ: Math.max(...visibleTiles.map((t) => t.z)) + worldSize * ring,
    }

    const visibleSet = new Set(visibleTiles.map((tile) => getTileKey(tile.x, tile.z)))
    const tilesToPreload: RenderTile[] = []

    const step = worldSize
    const levelLookup = selectedLevel?.lookup
    const baseVisible = !levelLookup ? getVisibleTiles() : []
    const baseMap =
      !levelLookup && baseVisible.length > 0
        ? new Map(baseVisible.map((tile) => [getTileKey(tile.x, tile.z), tile]))
        : null

    for (let x = bounds.minX; x <= bounds.maxX; x += step) {
      for (let z = bounds.minZ; z <= bounds.maxZ; z += step) {
        const key = getTileKey(x, z)
        if (visibleSet.has(key)) continue
        const tile = levelLookup?.get(key) || baseMap?.get(key)
        if (tile && !getCachedTile(tile)) {
          tilesToPreload.push(tile as RenderTile)
        }
      }
    }

    const limit = camera.zoom <= 0.2 ? 48 : 24
    await preloadTiles(tilesToPreload.slice(0, limit))
  }

  onMounted(() => {
    initCanvas()
    void loadMipManifest()
    window.addEventListener('resize', resizeCanvas)
  })

  onUnmounted(() => {
    if (animationFrameId.value) {
      cancelAnimationFrame(animationFrameId.value)
    }
    window.removeEventListener('resize', resizeCanvas)
  })

  return {
    ctx,
    resizeCanvas,
    requestRender,
    preloadSurroundingTiles,
    loadMissingTiles,
  }
}
